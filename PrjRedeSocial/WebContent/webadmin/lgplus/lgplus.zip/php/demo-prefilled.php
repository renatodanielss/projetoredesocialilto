<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<title>Rico LiveGrid Plus-Example 1</title>

<script src="../js/prototype.js" type="text/javascript"></script>
<script src="../js/ricoCommon.js" type="text/javascript"></script>
<script src="../js/ricoEffects.js" type="text/javascript"></script>
<script src="../js/ricoLiveGrid.js" type="text/javascript"></script>
<link href="../css/ricoLiveGrid.css" type="text/css" rel="stylesheet" />
<link href="../css/demo.css" type="text/css" rel="stylesheet" />

<? 
require "chklang.php";
?>
</head>

<body onload="bodyOnLoad()">

<?
require "menu.php";
print "<table border='0' cellpadding='0' cellspacing='0'><tr valign='top'><td id='settings'>";
require "settings.php";
?>
</td><td>&nbsp;</td>
<td><div id='explanation'><p>This example demonstrates a pre-filled grid (no AJAX data fetches). 
LiveGrid Plus just provides scrolling, column resizing, and sorting capabilities.
The first column sorts numerically, the others sort in text order.
Use the panel to the left to change grid settings.
Filtering is not supported on pre-filled grids.
</p></div></td></td></table>
<script type="text/javascript">

function bodyOnLoad() {
  Rico.Corner.round('settings')
  Rico.Corner.round('explanation')
  var opts = {  
               menuEvent     : '<? print $menu; ?>',
               frozenColumns : <? print $frozen; ?>,
               canSortDefault: <? print $sort; ?>,
               canHideDefault: <? print $hide; ?>,
               allowColResize: <? print $resize; ?>,
               canFilterDefault: <? print $filter; ?>,
               highltOnMouseOver: <? print $highlt; ?>,
               columnSpecs   : ['specQty'],
               prefetchBuffer: false
             };
  // -1 on the next line tells LiveGrid to determine the number of rows based on window size
  new Rico.LiveGrid ('ex1', 10, 100, null, opts);
}

</script>
<p class="ricoBookmark"><span id="ex1_bookmark">&nbsp;</span></p>
<table id="ex1" class="ricoLiveGrid" cellspacing="0" cellpadding="0">
<colgroup>
<?
$numcol=15;
for ($c=1; $c<=$numcol; $c++) {
  print "<col style='width:80px;' />";
}
?>
</colgroup>
<thead><tr>
<?
for ($c=1; $c<=$numcol; $c++) {
  print "<th>Column $c</th>";
}
?>
</tr></thead><tbody>
<?
for ($r=1; $r<=100; $r++) {
  print "<tr>";
  print "<td>$r</td>";
  for ($c=2; $c<=$numcol; $c++) {
    print "<td>Cell $r:$c</td>";
  }
  print "</tr>";
}
?>
</tbody></table>

<!--
<textarea id='ex1_debugmsgs' rows='5' cols='80' style='font-size:smaller;'></textarea>
-->

</body>
</html>


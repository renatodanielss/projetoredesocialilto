<?
$curscript=basename($_SERVER['SCRIPT_NAME']);
$scripts=array("demo-prefilled.php","demo-autosize.php","demo-autosize2.php","demo-3grids.php","demo-headings.php","demo-ordersum.php","demo-chkbox.php");
print "<strong style='color:brown;'>Rico LiveGrid Plus</strong>";
print "\n<table border='0' cellpadding='5'>\n<tr>";
print "<td><a href='../'>Release Home</a></td>";
foreach ($scripts as $k => $v) {
  $k++;
  if ($v==$curscript)
    print "<td><strong style='border:1px solid brown;color:brown;'>Ex $k</strong></td>";
  else
    print "<td><a href='$v'>Ex $k</a></td>";
}
print "</tr>\n</table>";
?>

<?
if (!isset ($_SESSION)) session_start();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<title>Rico LiveGrid Plus-Example 2</title>

<script src="../js/prototype.js" type="text/javascript"></script>
<script src="../js/ricoCommon.js" type="text/javascript"></script>
<script src="../js/ricoEffects.js" type="text/javascript"></script>
<script src="../js/ricoLiveGrid.js" type="text/javascript"></script>
<link href="../css/ricoLiveGrid.css" type="text/css" rel="stylesheet" />
<link href="../css/demo.css" type="text/css" rel="stylesheet" />

<? 
require "chklang.php";
$sqltext="select OrderID,CustomerID,ShipName,ShipCity,ShipCountry,OrderDate,ShippedDate from nworders";
$_SESSION['ordergrid']=$sqltext;
?>

</head>

<body onload="bodyOnLoad()">

<?
require "menu.php";
print "<table border='0' cellpadding='0' cellspacing='0' style='clear:both'><tr valign='top'><td id='settings'>";
require "settings.php";
?>
</td><td>&nbsp;</td>
<td><div id='explanation'><p>This example uses AJAX to fetch order data as required. 
It also demonstrates how the number of rows can be set automatically based
on the size of the window.
</p></div></td></td></table>

<script type="text/javascript">
var customerGrid, orderGrid, detailGrid;

function bodyOnLoad() {
  Rico.Corner.round('settings')
  Rico.Corner.round('explanation')
  var opts = {  
               menuEvent     : '<? print $menu; ?>',
               frozenColumns : <? print $frozen; ?>,
               canSortDefault: <? print $sort; ?>,
               canHideDefault: <? print $hide; ?>,
               allowColResize: <? print $resize; ?>,
               canFilterDefault: <? print $filter; ?>,
               highltOnMouseOver: <? print $highlt; ?>,
               specDate      : {type:'date',canFilter:true},
               columnSpecs   : [,,,,,'specDate','specDate'],
               prefetchBuffer: true
             };
  // -1 on the next line tells LiveGrid to determine the number of rows based on window size
  orderGrid=new Rico.LiveGrid ('ordergrid', -1, 100, 'northwindxmlquery.php',opts);
}
</script>

<p class="ricoBookmark"><span id="ordergrid_bookmark">&nbsp;</span></p>
<table id="ordergrid_header" class="ricoLiveGrid" cellspacing="0" cellpadding="0">
<colgroup>
<col style='width:50px;' >
<col style='width:60px;' >
<col style='width:150px;'>
<col style='width:80px;' >
<col style='width:110px;' >
<col style='width:100px;'>
<col style='width:100px;'>
</colgroup>
  <tr>
	  <th>Order#</th>
	  <th>Customer#</th>
	  <th>Ship Name</th>
	  <th>Ship City</th>
	  <th>Ship Country</th>
	  <th>Order Date</th>
	  <th>Ship Date</th>
  </tr>
</table>
<!--
<textarea id='ordergrid_debugmsgs' rows='5' cols='80'>
-->
</body>
</html>


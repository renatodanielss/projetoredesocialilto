<?
if (!isset ($_SESSION)) session_start();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<title>Rico LiveGrid Plus-Example 6</title>

<script src="../js/prototype.js" type="text/javascript"></script>
<script src="../js/ricoCommon.js" type="text/javascript"></script>
<script src="../js/ricoEffects.js" type="text/javascript"></script>
<script src="../js/ricoLiveGrid.js" type="text/javascript"></script>
<link href="../css/ricoLiveGrid.css" type="text/css" rel="stylesheet" />
<link href="../css/demo.css" type="text/css" rel="stylesheet" />

<? 
require "chklang.php";
$sqltext="select '<input type=\"checkbox\">',CustomerID,year(ShippedDate),count(*) from nworders group by CustomerID,year(ShippedDate)";
$_SESSION['ex8']=$sqltext;
?>

<style type="text/css">
td div.ricoLG_cell { height:1.5em; }  /* the check boxes require a little more height than normal */
td.ex8_col0,
td.ex8_col2,
td.ex8_col3 {
text-align:center;
}
</style>

</head>

<body onload="bodyOnLoad()">

<?
require "menu.php";
print "<table border='0' cellpadding='0' cellspacing='0' style='clear:both'><tr valign='top'><td id='settings'>";
require "settings.php";
?>
</td><td>&nbsp;</td>
<td><div id='explanation'><p>This grid uses grouping and a where clause in the select statement. 
It also places a checkbox on every row.
The checkboxes are only included to demonstrate a capability,
they don't actually do anything useful in this example.
</p></div></td></td></table>

<script type="text/javascript">
var ex8;

function setFilter() {
  for (var i=0; i<yrboxes.length; i++) {
    if (yrboxes[i].checked==true) {
      var yr=yrboxes[i].value;
      ex8.columns[2].setSystemFilter('=',yr);
      return;
    }
  }
}

function bodyOnLoad() {
  Rico.Corner.round('settings')
  Rico.Corner.round('explanation')
  yrboxes=document.getElementsByName('year');
  var opts = {  
               menuEvent     : '<? print $menu; ?>',
               frozenColumns : <? print $frozen; ?>,
               canSortDefault: <? print $sort; ?>,
               canHideDefault: <? print $hide; ?>,
               allowColResize: <? print $resize; ?>,
               canFilterDefault: <? print $filter; ?>,
               highltOnMouseOver: <? print $highlt; ?>,
               prefetchBuffer: false,
               columnSpecs   : [,,,'specQty']
             };
  ex8=new Rico.LiveGrid ('ex8', 10, 50, 'northwindxmlquery.php',opts);
  setFilter();
}
</script>

<p>Count orders for: 
<input type='radio' name='year' onclick='setFilter()' value='1996' checked>&nbsp;1996
<input type='radio' name='year' onclick='setFilter()' value='1997'>&nbsp;1997
</p>

<p class="ricoBookmark"><span id="ex8_bookmark">&nbsp;</span></p>
<table id="ex8_header" class="ricoLiveGrid" cellspacing="0" cellpadding="0">
<colgroup>
<col style='width:40px;' >
<col style='width:60px;' >
<col style='width:40px;' >
<col style='width:40px;' >
</colgroup>
  <tr>
	  <th>Select</th>
	  <th>Customer#</th>
	  <th>Year</th>
	  <th>Order Count</th>
  </tr>
</table>
<!--
<textarea id='ex8_debugmsgs' rows='5' cols='80'>
-->
</body>
</html>


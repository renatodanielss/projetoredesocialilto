<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<title>Rico LiveGrid Plus-Example 5</title>

<script src="../js/prototype.js" type="text/javascript"></script>
<script src="../js/ricoCommon.js" type="text/javascript"></script>
<script src="../js/ricoEffects.js" type="text/javascript"></script>
<script src="../js/ricoLiveGrid.js" type="text/javascript"></script>
<link href="../css/ricoLiveGrid.css" type="text/css" rel="stylesheet" />
<link href="../css/demo.css" type="text/css" rel="stylesheet" />

<? 
require "chklang.php";
?>
</head>

<body onload="bodyOnLoad()">

<?
require "menu.php";
print "<table border='0' cellpadding='0' cellspacing='0' style='clear:both'><tr valign='top'><td id='settings'>";
require "settings.php";
?>
</td><td>&nbsp;</td>
<td><div id='explanation'><p>This example demonstrates multiple rows in the heading.
A pre-filled grid is used in this example, but multi-row headings
can just as easily be used with AJAX-filled grids.
</p></div></td></td></table>

<script type="text/javascript">

function bodyOnLoad() {
  Rico.Corner.round('settings')
  Rico.Corner.round('explanation')
  var opts = {  
               menuEvent     : '<? print $menu; ?>',
               frozenColumns : <? print $frozen; ?>,
               canSortDefault: <? print $sort; ?>,
               canHideDefault: <? print $hide; ?>,
               allowColResize: <? print $resize; ?>,
               canFilterDefault: <? print $filter; ?>,
               highltOnMouseOver: <? print $highlt; ?>,
               headingRow    : 1,
               columnSpecs   : ['specQty'],
               prefetchBuffer: false
             };
  // -1 on the next line tells LiveGrid to determine the number of rows based on window size
  new Rico.LiveGrid ('ex5', 10, 100, null, opts);
}
</script>

<p class="ricoBookmark"><span id="ex5_bookmark">&nbsp;</span></p>
<table id="ex5" class="ricoLiveGrid" cellspacing="0" cellpadding="0">
<colgroup>
<?
$numcol=15;
$divisor=3;

for ($c=1; $c<=$numcol; $c++) {
  print "<col style='width:80px;' />";
}
?>
</colgroup>
<thead>
<tr>
<?
$n=floor($numcol / $divisor);
for ($c=1; $c<=$n; $c++) {
  print "<th colspan=$divisor>Section $c</th>";
}
?>
</tr>
<tr>
<?
for ($c=1; $c<=$numcol; $c++) {
  print "<th>Column $c</th>";
}
?>
</tr>
</thead><tbody>
<?
for ($r=1; $r<=100; $r++) {
  print "<tr>";
  print "<td>$r</td>";
  for ($c=2; $c<=$numcol; $c++) {
    print "<td>Cell $r:$c</td>";
  }
  print "</tr>";
}
?>
</tbody></table>

<!--
<textarea id='ex5_debugmsgs' rows='5' cols='80' style='font-size:smaller;'></textarea>
-->

</body>
</html>


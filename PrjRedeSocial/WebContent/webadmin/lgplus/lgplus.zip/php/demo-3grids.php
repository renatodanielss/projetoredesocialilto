<?
if (!isset ($_SESSION)) session_start();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<title>Rico LiveGrid Plus-Example 4</title>

<script src="../js/prototype.js" type="text/javascript"></script>
<script src="../js/ricoCommon.js" type="text/javascript"></script>
<script src="../js/ricoLiveGrid.js" type="text/javascript"></script>
<link href="../css/ricoLiveGrid.css" type="text/css" rel="stylesheet" />

<?
require "chklang.php";

$_SESSION['customergrid']="select CustomerID,CompanyName,ContactName,Address,City,ifnull(Region,''),ifnull(PostalCode,''),Country,ifnull(Phone,''),ifnull(Fax,'') from nwcustomers";
$_SESSION['ordergrid']="select CustomerID,OrderID,ShipName,ShipCity,ShipCountry,OrderDate,ShippedDate from nworders";
$_SESSION['detailgrid']="select OrderID,p.ProductName,QuantityPerUnit,od.UnitPrice,Quantity,od.UnitPrice*Quantity,Discount,od.UnitPrice*Quantity*(1.0-Discount) from nworderdetails od left join nwproducts p on od.ProductID=p.ProductID";
?>

<script type="text/javascript">
var customerGrid, orderGrid, detailGrid;

function bodyOnLoad() {
  var opts = {  prefetchBuffer: true,
                frozenColumns : 2,
                dataMenuHandler: customerDataMenu
             };
  customerGrid=new Rico.LiveGrid ('customergrid', 5, 100, 'northwindxmlquery.php',opts);
  var opts = {  prefetchBuffer: false,
                specFirstCol  : {canSort:false,visible:false},
                specDate      : {type:'date',canFilter:true},
                columnSpecs   : ['specFirstCol',,,,,'specDate','specDate'],
                canFilterDefault: false,
                dataMenuHandler: orderDataMenu
             };
  orderGrid=new Rico.LiveGrid ('ordergrid', 5, 5, 'northwindxmlquery.php',opts);
  var opts = {  prefetchBuffer: false,
                specFirstCol  : {canSort:false,visible:false},
                columnSpecs   : ['specFirstCol',,,'specDollar','specQty','specDollar','specPercent','specDollar'],
                canFilterDefault: false,
                dataMenuHandler: detailDataMenu
             };
  detailGrid=new Rico.LiveGrid ('detailgrid', 5, 5, 'northwindxmlquery.php',opts);
}

var custid,orderid;

function customerDataMenu(objCell,onBlankRow) {
  if (onBlankRow==true) return true;
  custid=customerGrid.columns[0].cell(objCell.rowIndex).getValue();
  gridMenu.addMenuHeading("Northwind");
  gridMenu.addMenuItem(RicoTranslate.getPhrase("Show orders for")+" "+custid,showOrders,custid!='');
  return true;
}

function showOrders() {
  $("custid").innerHTML=custid;
  $("orderid").innerHTML="";
  orderGrid.columns[0].setSystemFilter("=",custid);
  detailGrid.resetContents();
}

function orderDataMenu(objCell,onBlankRow) {
  if (orderGrid.isBlank!=false) return false;
  if (onBlankRow==true) return true;
  orderid=orderGrid.columns[1].cell(objCell.rowIndex).getValue();
  gridMenu.addMenuHeading("Northwind");
  gridMenu.addMenuItem("Show order detail",showOrderDetail,orderid!='');
  return true;
}

function showOrderDetail() {
  $("orderid").innerHTML=orderid;
  detailGrid.columns[0].setSystemFilter("=",orderid);
}

function detailDataMenu(objCell,onBlankRow) {
  if (detailGrid.isBlank!=false) return false;
  return true;
}

</script>

<style type="text/css">
div.container {
float:left;
margin-left:2%;
width:75%;
overflow:hidden; /* this is very important! */
}

/* show positive discounts in blue */
td.detailgrid_col6 span.posNumber {
color:blue;
}

td.detailgrid_col3, 
td.detailgrid_col4, 
td.detailgrid_col5, 
td.detailgrid_col6, 
td.detailgrid_col7 {
text-align:right;
}
</style>

</head>

<body onload="bodyOnLoad()">

<?
require "menu.php";
?>

<div style='float:left;clear:both;font-size:9pt;width:18%;color:blue;font-family:Verdana, Arial, Helvetica, sans-serif;'>
Double-click on a row and select "Show orders" to see all orders for that customer.
<p>Drag the edge of a column heading to resize a column.
<p>To filter: double-click on the value that you would like to use as the basis for filtering, then select the desired filtering method from the pop-up menu.
<p>Double-click anywhere in a column to see sort, hide, and show options.
</div>

<div class="container">
<p class="ricoBookmark"><strong>Customers</strong>
<span id="customergrid_bookmark" style="font-size:10pt;padding-left:4em;">&nbsp;</span>
</p>
<table id="customergrid_header" class="ricoLiveGrid" cellspacing="0" cellpadding="0">
<colgroup>
<col style='width:60px;' >
<col style='width:150px;' >
<col style='width:115px;'>
<col style='width:130px;' >
<col style='width:90px;' >
<col style='width:60px;' >
<col style='width:90px;' >
<col style='width:100px;'>
<col style='width:115px;'>
<col style='width:115px;'>
</colgroup>
  <tr>
	  <th>Customer#</th>
	  <th>Company</th>
	  <th>Contact</th>
	  <th>Address</th>
	  <th>City</th>
	  <th>Region</th>
	  <th>Postal Code</th>
	  <th>Country</th>
	  <th>Phone</th>
	  <th>Fax</th>
  </tr>
</table>

<p class="ricoBookmark"><strong>Orders for <span id="custid"></span></strong>
<span id="ordergrid_bookmark" style="font-size:10pt;padding-left:4em;">&nbsp;</span>
</p>
<table id="ordergrid_header" class="ricoLiveGrid" cellspacing="0" cellpadding="0">
<colgroup>
<col style='width:5px;'  >
<col style='width:60px;' >
<col style='width:150px;'>
<col style='width:80px;' >
<col style='width:90px;' >
<col style='width:100px;'>
<col style='width:100px;'>
</colgroup>
  <tr>
	  <th>Customer#</th>
	  <th>Order#</th>
	  <th>Ship Name</th>
	  <th>Ship City</th>
	  <th>Ship Country</th>
	  <th>Order Date</th>
	  <th>Ship Date</th>
  </tr>
</table>

<p class="ricoBookmark"><strong>Order #<span id="orderid"></span></strong>
<span id="detailgrid_bookmark" style="font-size:10pt;padding-left:4em;">&nbsp;</span>
</p>
<table id="detailgrid_header" class="ricoLiveGrid" cellspacing="0" cellpadding="0">
<colgroup>
<col style='width:5px;'  >
<col style='width:150px;'>
<col style='width:125px;'>
<col style='width:80px;' >
<col style='width:50px;' >
<col style='width:80px;' >
<col style='width:80px;' >
<col style='width:90px;' >
</colgroup>
  <tr>
	  <th>Order #</th>
	  <th>Description</th>
	  <th>Unit Quantity</th>
	  <th>Unit Price</th>
	  <th>Qty</th>
	  <th>Total</th>
	  <th>Discount</th>
	  <th>Net Price</th>
  </tr>
</table>

</div>

<!--
<table border="0"><tr>
<td><textarea id='customergrid_debugmsgs' rows='5' cols='30'></textarea>
<td><textarea id='ordergrid_debugmsgs' rows='5' cols='30'></textarea>
<td><textarea id='detailgrid_debugmsgs' rows='5' cols='30'></textarea>
</tr></table>
-->

</body>
</html>


<?
if (isset($_GET['menu'])) {
  $menu=$_GET['menu'];
  $frozen=isset($_GET['frozen']) ? $_GET['frozen'] : 1;
  $sort=isset($_GET['sort']) ? $_GET['sort'] : 'false';
  $hide=isset($_GET['hide']) ? $_GET['hide'] : 'false';
  $filter=isset($_GET['filter']) ? $_GET['filter'] : 'false';
  $resize=isset($_GET['resize']) ? $_GET['resize'] : 'false';
  $highlt=isset($_GET['highlt']) ? $_GET['highlt'] : 'false';
} else {
  $menu='dblclick';
  $frozen=1;
  $sort='true';
  $hide='true';
  $filter=isset($sqltext) ? 'true' : 'false';
  $resize='true';
  $highlt='true';
}
print "<form><table border='0' cellspacing='0'>";
print "\n<tr valign='top'><td colspan='2'><input type='submit' value='Change Settings' style='font-size:small'></td>";
print "<td rowspan='3'>&nbsp;</td>";
print "<td rowspan='3'><table border='0' cellspacing='0' cellpadding='0'>";
print "<tr><td><input type='checkbox' value='true' name='sort' ".($sort=='true'?'checked':'')."><td>Sorting?</td></tr>";
print "<tr><td><input type='checkbox' value='true' name='filter' ".(isset($sqltext) ? '' : 'disabled ').($filter=='true'?'checked':'')."><td>Filtering?</td></tr>";
print "<tr><td><input type='checkbox' value='true' name='hide' ".($hide=='true'?'checked':'')."><td>Hide/Show?</td></tr>";
print "<tr><td><input type='checkbox' value='true' name='resize' ".($resize=='true'?'checked':'')."><td>Resizing?</td></tr>";
print "<tr><td><input type='checkbox' value='true' name='highlt' ".($highlt=='true'?'checked':'')."><td>Highlight on MouseOver?</td></tr>";
print "</table></td></tr>";
print "\n<tr><td>Menu&nbsp;event:</td><td><select name='menu'>";
print "<option ".($menu=='click'?'selected':'')." value='click'>Click</option>";
print "<option ".($menu=='dblclick'?"selected":'')." value='dblclick'>Double-click</option>";
print "<option ".($menu=='contextmenu'?'selected':'')." value='contextmenu'>Right-click</option>";
print "<option ".($menu=='none'?'selected':'')." value='none'>None</option>";
print "</select></td></tr>";
print "\n<tr><td>Frozen columns:</td><td><select name='frozen'>";
for ($i=0; $i<4; $i++)
  print "<option ".(($frozen==$i)?'selected':'')." value='$i'>$i</option>";
print "</select></td></tr>";
print "\n</table></form>";
?>

<?
if (!isset ($_SESSION)) session_start();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<title>Rico LiveGrid Plus-Example 3</title>

<script src="../js/prototype.js" type="text/javascript"></script>
<script src="../js/ricoCommon.js" type="text/javascript"></script>
<script src="../js/ricoEffects.js" type="text/javascript"></script>
<script src="../js/ricoLiveGrid.js" type="text/javascript"></script>
<link href="../css/ricoLiveGrid.css" type="text/css" rel="stylesheet" />
<link href="../css/demo.css" type="text/css" rel="stylesheet" />

<? 
require "chklang.php";
$sqltext="select OrderID,CustomerID,ShipName,ShipCity,ShipCountry,OrderDate,ShippedDate from nworders";
$_SESSION['ex3']=$sqltext;
?>

<style type="text/css">
input { font-weight:normal;font-size:8pt;}
th div.ricoLG_cell { height:1.5em; }  /* the text boxes require a little more height than normal */
</style>

</head>

<body onload="bodyOnLoad()">

<?
require "menu.php";
print "<table border='0' cellpadding='0' cellspacing='0' style='clear:both'><tr valign='top'><td id='settings'>";
require "settings.php";
?>
</td><td>&nbsp;</td>
<td><div id='explanation'><p>This grid demonstrates how filters can be applied as the user types.
Frozen columns would normally be set to 2 for this grid, but feel free to try other values.
</p></div></td></td></table>
<p class="ricoBookmark"><span id="ex3_bookmark">&nbsp;</span></p>
<script type="text/javascript">
var customerGrid, ex3, detailGrid;

function bodyOnLoad() {
  Rico.Corner.round('settings')
  Rico.Corner.round('explanation')
  var opts = {  
               menuEvent     : '<? print $menu; ?>',
               frozenColumns : <? print $frozen; ?>,
               canSortDefault: <? print $sort; ?>,
               canHideDefault: <? print $hide; ?>,
               allowColResize: <? print $resize; ?>,
               canFilterDefault: <? print $filter; ?>,
               highltOnMouseOver: <? print $highlt; ?>,
               specDate      : {type:'date',canFilter:true},
               columnSpecs   : [,,,,,'specDate','specDate'],
               headingRow    : 1,
               prefetchBuffer: true
             };
  // -1 on the next line tells LiveGrid to determine the number of rows based on window size
  ex3=new Rico.LiveGrid ('ex3', -1, 100, 'northwindxmlquery.php',opts);
}

function keyfilter(txtbox,idx) {
  ex3.columns[idx].setFilter('LIKE',txtbox.value+'%',Rico.TableColumn.USERFILTER,function() {txtbox.value='';});
}

</script>

<table id="ex3_header" class="ricoLiveGrid" cellspacing="0" cellpadding="0">
<colgroup>
<col style='width:60px;' >
<col style='width:60px;' >
<col style='width:150px;'>
<col style='width:80px;' >
<col style='width:90px;' >
<col style='width:100px;'>
<col style='width:100px;'>
</colgroup>
  <tr>
	  <th colspan='2'>ID</th>
	  <th colspan='3'>Shipment</th>
	  <th colspan='2'>Date</th>
  </tr>
  <tr>
	  <th>Order</th>
	  <th>Customer</th>
	  <th>Name</th>
	  <th>City</th>
	  <th>Country</th>
	  <th>Order</th>
	  <th>Ship</th>
  </tr>
  <tr class='dataInput'>
    
	  <th><input type='text' onkeyup='keyfilter(this,0)'></th>
	  <th><input type='text' onkeyup='keyfilter(this,1)'></th>
	  <th><input type='text' onkeyup='keyfilter(this,2)'></th>
	  <th><input type='text' onkeyup='keyfilter(this,3)'></th>
	  <th><input type='text' onkeyup='keyfilter(this,4)'></th>
	  <th>&nbsp;</th>
	  <th>&nbsp;</th>
	  
  </tr>
</table>

<!--
<textarea id='ex3_debugmsgs' rows='5' cols='80' style='font-size:smaller;'></textarea>
-->

</body>
</html>

